from django.contrib.auth.forms import AuthenticationForm , UserCreationForm
from django import forms
from django.contrib.auth.models import User
from . models import ImageModel


class UserAuthentication(AuthenticationForm):
    # username = forms.UsernameField(widget=forms.TextInput(attrs={"autofocus": True}))
    username = forms.CharField(label="Enter Username" , widget=forms.TextInput(attrs={'class':'form-control'}))
    password = forms.CharField(
        label=("Enter Password"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password" , 'class':'form-control'}),
    )

    class Meta:
        model = User
        fields = ['username' ]
        labels = {
            'password':'Enter Password'
        }

        
class RegisterForm(UserCreationForm):
    password1 = forms.CharField(label='Enter Password' ,widget=forms.PasswordInput(attrs={'class':'form-control'}))

    password2 = forms.CharField(label='Confirm Password' ,widget=forms.PasswordInput(attrs={'class':'form-control'}))

    email = forms.EmailField(
        label=("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={"class": "form-control"}),
    )

    class Meta:
        model = User
        fields = ['username' , 'first_name' , 'last_name' , 'email' , 'password1' , 'password2']

        labels = {
            'username':'Enter Username',
            'first_name' :'Enter First Name',
            'last_name' : 'Enter Last Name',
            'email' :'Enter Email-ID',
        }

        widgets = {
            'username' : forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            
        }


class AddImageForm(forms.ModelForm):
    class Meta:
        model = ImageModel
        fields = ['title' , 'cat','image' ,'desc']

        labels = {
            'title' :'Image Title',
            'desc' :'Image Description',
            'cat':'Image Category',
            'image':'Upload Image'
        }

        widgets = {
            'title' : forms.TextInput(attrs={'class':'form-control'}),
            'desc' : forms.Textarea(attrs={'class':'form-control'}),
            'cat': forms.Select(attrs={'class':'form-control w-75'}),
            'image':forms.FileInput(attrs={'class':'form-control'})
        }