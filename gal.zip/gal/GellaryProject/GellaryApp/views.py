from django.shortcuts import render,redirect 
from . forms import UserAuthentication ,RegisterForm , AddImageForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages 
from . models import CategoryModel,ImageModel


from django.contrib.auth import authenticate , login , logout

# Create your views here.


def home_view(request):
    if request.user.is_authenticated:
        return redirect('gellary')
    forms = UserAuthentication()
    context = {'forms':forms}

    return render(request , 'GellaryApp/home.html' , context)

def register_view(request):
    forms = RegisterForm()

    if request.method == "POST":
        forms = RegisterForm(request.POST)
        if forms.is_valid():
            username = request.POST['username']
            forms.save()
            print("User Register")
            messages.success(request , f'Successfully {username} Registerd ')
            return redirect('home')
    context = {'forms':forms}
    return render(request , 'GellaryApp/register.html' , context)

def signin_view(request):
    
    if request.method == 'POST':
        
        username = request.POST['username']
        pass1 = request.POST['password']
        user = authenticate(username = username , password = pass1)
        if user is not None:
            login(request , user)

            # print("User is ",user)
            messages.success(request , f'Successfully {username} Loggedin ')
            return redirect('gellary')

        else:
            messages.warning(request , f'something went wrong while login') 
            return redirect('home')

    return redirect('home')

def signout_view(request):
    logout(request)
    messages.success(request , 'Successfully user Logout')
    return redirect('home')

def gellary_view(request):

    categories = CategoryModel.objects.all()
    images = ImageModel.objects.all()
    context = {
        'categories':categories,
        'images':images
    }

    return render(request , 'GellaryApp/gellary.html',context)

def cat_image_view(request , id):
    categories = CategoryModel.objects.all()
    cats = CategoryModel.objects.get(id = id)
    images = ImageModel.objects.filter(cat = cats)

    context = {
        'categories':categories,
        'images':images
    }
    return render(request , 'GellaryApp/gellary.html',context)


def addimage_view(request):

    forms = AddImageForm()
    if request.method == "POST":
        forms = AddImageForm(request.POST , request.FILES)
        if forms.is_valid():
            forms.save()
            messages.success(request , 'Image successfully Upload ')
            return redirect('gellary')
        
        else:
            messages.warning(request , 'Image Not Uploaded ')
            return redirect('addimage_view')



    context = {
        'forms':forms
    }


    return render(request, 'GellaryApp/addimage.html' , context)