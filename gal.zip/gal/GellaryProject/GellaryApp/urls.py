from django.urls import path
from . import views

urlpatterns = [
    path('' , views.home_view , name = 'home'),
    path('register/' , views.register_view , name = 'register'),
    path('signin/' , views.signin_view , name = 'signin'),
    path('signout/' , views.signout_view , name = 'signout'),
    path('gellary/' , views.gellary_view , name = 'gellary'),
    path('addimage/' , views.addimage_view , name = 'addimage'),
    path('cat_image/<int:id>' , views.cat_image_view , name = 'cat_image'),
    
]